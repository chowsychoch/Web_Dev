This is a personal website for myself. It contains 5 html files including Home, About, Work & Play, Projects, Contact

For the nav bar, unordered list element is used to create a horizontal nav bar. The nav bar is across the five html pages to link to each other.

For index.html, background image is used with the effect of opacity. In order to create a clear contrast of background and fonts. z-index property is used to create font at the top layer. Also, button to link to the About.html to let user know about me. 

For about.html, it consist of 4 parts. Brief intro., Skill Set, Timeline and courses I m taking. The image is scaled with the overflow property. As I have a number of images that is different size and shapes. So I make them a circle by using border radius element and overflow set to hidden. By scaling the size of image. width percentage and margin is used to control the size and position of image. Also, I put images link to external webpages with <a> tag For skills set, I created four bars to indicate different levels and I add an effect of load animation for two second so the percentage of skills is gradually increase when user load the pages. For timeline, this is used mainly with flex model to align the box in a vertical column. Finally, Table is showed to describe the course im taking. 

For Work & Play, a set of images using a card design is show. To align the the card, display for inline-block is used. And image is scaled with overflow property. Also, hover effect is used when user mouses stop at cards. 

For Project.html, a flex model is used to align the content of description and image/video. I embedded video From Youtube. And image to link to external instagram pages.

Finally, contact html, a simple form is used for that with submit button.

I explored additional css and html element by using stackoverflow, reading w3school and reading some blog on medium.


